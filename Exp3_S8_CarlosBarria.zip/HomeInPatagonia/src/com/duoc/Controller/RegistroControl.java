package com.duoc.Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import com.duoc.Model.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 20-09-2024
 * @asignatura: Desarrollo Orientado a Objetos II
 * @actividad: Sumativa Semana 8
 *
 */
public class RegistroControl {

    private final List<Pelicula> peliculas;
    private final DatabaseConnection conectorBD;

    public RegistroControl() {
        peliculas = new ArrayList<>();
        conectorBD = new DatabaseConnection();
    }

    //Consulta Películas desde el form Lista
    public List<Pelicula> getPeliculasFromDB() {
        List<Pelicula> peliculas = new ArrayList<>();
        String sqlListar = "SELECT * FROM movie";
        try {
            Connection conexRead = conectorBD.getConnection();
            if (!conexRead.isClosed()) {
                Statement stConsultar = conexRead.createStatement();
                ResultSet rsListar = stConsultar.executeQuery(sqlListar);

                while (rsListar.next()) {
                    String titulo = rsListar.getString("titulo");
                    String director = rsListar.getString("director");
                    int anio = rsListar.getInt("anio");
                    int duracion = rsListar.getInt("duracion");
                    String genero = rsListar.getString("genero");
                    Pelicula peli = new Pelicula(titulo, director, anio, duracion, genero);
                    peliculas.add(peli);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtenre los datos de Películas " + e.getMessage());
        }
        return peliculas;
    }

    //Método que agrega peliculas desde el formulario Ingresa
    public void addPelicula(Pelicula pelicula) throws SQLException {
        peliculas.add(pelicula);
        ingresarPelicula((Pelicula) pelicula);
    }

    //Método Ingresar Película a la base de datos en la tabla "movie"
    public void ingresarPelicula(Pelicula peli) throws SQLException {
        String sqlInsert = "INSERT INTO `movie` (`id`, `titulo`, `director`, `anio`, `duracion`, `genero`) VALUES (NULL,?,?,?,?,?)";
        Connection conexCreate = conectorBD.getConnection();
        PreparedStatement stIngresar = conexCreate.prepareStatement(sqlInsert);
        try {
            stIngresar.setString(1, peli.getTitulo());
            stIngresar.setString(2, peli.getDirector());
            stIngresar.setInt(3, peli.getAño());
            stIngresar.setInt(4, peli.getDuracion());
            stIngresar.setString(5, peli.getGenero());
            stIngresar.executeUpdate();
            System.out.println("Película ingresada correctamente.");
            //Mensaje en pantalla
            JOptionPane.showMessageDialog(null, "Ingreso realizado correctamente!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            System.out.println("Error al obtenrer los datos de las Películas" + e.getMessage());
        }
    }

    //Buscar película por titulo
    public Pelicula buscarPeliculaPorTitulo(String tituloB) throws SQLException {
        String sqlSelect = "SELECT * FROM movie WHERE titulo = ?";
        Connection conexRead = conectorBD.getConnection();
        PreparedStatement stActualizar = conexRead.prepareStatement(sqlSelect);
        try {
            if (conexRead == null || conexRead.isClosed()) {
                System.out.println("La conexión está cerrada o es nula.");
                return null;
            }
            try {
                stActualizar.setString(1, tituloB);
                ResultSet rsBuscar = stActualizar.executeQuery();
                if (rsBuscar.next()) {
                    String director = rsBuscar.getString("director");
                    int año = rsBuscar.getInt("anio");
                    int duracion = rsBuscar.getInt("duracion");
                    String genero = rsBuscar.getString("genero");
                    return new Pelicula(tituloB, director, año, duracion, genero);
                }
            } catch (SQLException e) {
                System.out.println("Error al ejecutar la Consulta: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error al obtenrer la conexión: " + e.getMessage());
        }
        return null;
    }

    //Método para Actualizar los datos de la película
    public boolean actualizarPelicula(String titulo, String director, int anio, int duracion, String genero) throws SQLException {
//        DatabaseConnection conexionBD = new DatabaseConnection();
        String sqlUpdate = "UPDATE movie SET titulo = ?, director =?, anio = ?, duracion =?, genero=? WHERE titulo = ?";
        Connection conexion = conectorBD.getConnection(); 
        PreparedStatement stActualizar = conexion.prepareStatement(sqlUpdate);
//        try (Connection conexion = conectorBD.getConnection(); PreparedStatement stActualizar = conexion.prepareStatement(sqlUpdate)) {
        try {
            //Asignar los valores a la setencia SQL
            stActualizar.setString(1, titulo);
            stActualizar.setString(2, director);
            stActualizar.setInt(3, anio);
            stActualizar.setInt(4, duracion);
            stActualizar.setString(5, genero);
            return stActualizar.executeUpdate() > 0;
//            //Ejecutar la sentencia de actualización
//            int filasActualizadas = stActualizar.executeUpdate();
//
//            //Verficiar si alguna fila fue actualizada
//            if (filasActualizadas > 0) {
//                System.out.println("Película actualizada en la BD con éxito");
//                return true;
//            } else {
//                System.out.println("No se encontró la película");
//                return false;
//            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar registro de la película " + e.getMessage());
            return false;
        }
    }

    //Método Eliminar Película
    public boolean eliminarPelicula(String titulo) throws SQLException {
        String consulta = "DELETE FROM movie WHERE titulo = (?)";
        Connection conexDelete = conectorBD.getConnection();
        PreparedStatement stEliminar = conexDelete.prepareStatement(consulta);
        try {
            stEliminar.setString(1, titulo);
            stEliminar.executeUpdate();
            System.out.println("Película eliminada con Éxito");
            return true;
        } catch (Exception e) {
            System.out.println("Error al obtener la Pelicula desde la BD " + e.getMessage());
        }
        return false;
    }
}
