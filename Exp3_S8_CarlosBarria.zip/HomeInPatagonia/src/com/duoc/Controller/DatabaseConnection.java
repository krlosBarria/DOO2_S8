package com.duoc.Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: 20-09-2024
 * @asignatura: Desarrollo Orientado a Objetos II
 * @actividad: Sumativa Semana 8
 *
 */
public class DatabaseConnection {

    // Variables de conexión
    private static final String URL = "jdbc:mysql://localhost:3306/moviesDB";
    private static final String USER = "root";
    private static final String PASSWORD = "eddie";

    //Variable de conexión
    private Connection connection;

    public DatabaseConnection() {
        conectar();
    }

    private void conectar() {
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión extablecida con éxito");
        } catch (SQLException e) {
            System.out.println("Error al establecer a conexión con la BD: " + e.getMessage());
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public void desconectar() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexión cerrada con éxito");
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión:" + e.getMessage());
            }
        }
    }
}
